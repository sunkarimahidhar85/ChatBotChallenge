# from flask import Flask
from collections import Counter
from flask import Flask, request, make_response
import requests
import json
import os
import datetime
import time
import pdfcrowd
import sys
# from flask_cors import cross_origin
# from SendEmail.sendEmail import EmailSender
# from logger import logger
# from email_templates import template_reader
from email import encoders
from email import charset as _charset
#from email._encoded_words import decode_b
import botocore.session
from botocore.client import Config
from botocore.exceptions import DataNotFoundError, UnknownServiceError
import boto3
import boto3.utils
from boto3.exceptions import ResourceNotExistsError, UnknownAPIVersionError
import os
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail
#import aws_controller
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
import boto3
import base64
import imgkit
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from pyvirtualdisplay import Display
from selenium import webdriver
os.environ['AWS_DEFAULT_REGION'] = 'us-east-1'
# from config_reader import ConfigReader
s3 = boto3.client('s3')
app = Flask(__name__)


def insertUserData(userID,userName,userPhone,userEmail):
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('CovidDialogFlowUserInfo')
    try:
        table.put_item(
            Item={
                'userID': userID,
                'userName': userName,
                'userPhone': userPhone,
                'userEmail': userEmail
            }
        )    
    except Exception as e:
        #print(e.response['Error']['Message'])
        print("Some Exception in inserting user::"+str(e))

def dialogFlowInput(userLocation,caseType,userId):
    print("in dialogFlowInput method::"+str(userLocation)+" and "+caseType+" and "+userId)
    if(userLocation.isdigit()):
        pin = userLocation
        pinCodeRequest = requests.get("https://wrcofd1ig5.execute-api.us-east-1.amazonaws.com/covidapi/zip/"+pin)
        pinCodeJSON=json.dumps(pinCodeRequest.text)
        if(pinCodeJSON.find("zipsuccess")>-1):
            res11 = pinCodeJSON.strip('"')
            res11 = res11.replace('\\','')
            parsed_json = (json.loads(res11))
            loaded_json = json.loads(json.dumps(parsed_json, indent=4, sort_keys=True))
            city = parsed_json.get("city")
            state = parsed_json.get("state")
            confirmed0 = state.get("confirmed")
            active0 = state.get("active")
            recovered0 = state.get("recovered")
            confirmed0 = state.get("confirmed")
            deaths0 = state.get("deaths")
            totals0 = int(confirmed0)+int(active0)+int(recovered0)+int(deaths0)
            finalMessage = city.get("district").upper()+" recorded "+str(city.get("confirmed"))+" confirmed cases. It belongs to "+state.get("state").upper()+" which has "+confirmed0+" confirmed, "+active0+" active, "+recovered0+" recovered, "+deaths0+" deaths, total "+str(totals0)+" cases"
            finalMessageResp = '{"fulfillmentMessages":[{"card":{"title":"",subtitle":"","imageUri":"https://maps.googleapis.com/maps/api/staticmap?center='+pin+'&zoom=13&size=600x300&maptype=roadmap&markers=color:blue|label:S|40.702147,-74.015794&markers=color:green|label:G|40.711614,-74.012318&markers=color:red|label:C|40.718217,-73.998284&key=REMOVED-KEY-HERE"}},{"text": {"text": ["'+finalMessage+'"]}}]}'
        else:
            finalMessage="Phew!! Did not catch that. No problem, you can use phrases like \'active cases in 530043\', \'Bengaluru deaths\', \'Confirmed cases in Tamil Nadu\' or \'map state deaths\' to get specific information. Thank you!"
            finalMessageResp = '{"fulfillmentMessages":[{"text": {"text": ["'+finalMessage+'"]}}]}'
    else:
        app.logger.error("city")
        city = userLocation.replace(" ","%20")
        state = userLocation.replace(" ","%20")
        app.logger.error("https://wrcofd1ig5.execute-api.us-east-1.amazonaws.com/covidapi/city/"+city)
        cityRequest = requests.get("https://wrcofd1ig5.execute-api.us-east-1.amazonaws.com/covidapi/city/"+city)
        cityJSON=json.dumps(cityRequest.text)
        stateRequest = requests.get("https://wrcofd1ig5.execute-api.us-east-1.amazonaws.com/covidapi/statename/"+state)
        stateJSON=json.dumps(stateRequest.text)
        if(cityJSON.find("citysuccess")>-1):
            res11 = cityJSON.strip('"')
            app.logger.error(res11)
            app.logger.error("res11")
            res11 = res11.replace('\\','')
            parsed_json = (json.loads(res11))
            loaded_json = json.loads(json.dumps(parsed_json, indent=4, sort_keys=True))
            active3 = parsed_json.get("state").get("active")
            confirmed3 = parsed_json.get("state").get("confirmed")
            recovered3 = parsed_json.get("state").get("recovered")
            deaths3 = parsed_json.get("state").get("deaths")
            total3 = int(active3)+int(confirmed3)+int(recovered3)+int(deaths3)
            finalMessage = parsed_json.get("district").upper()+" has "+str(parsed_json.get("confirmed"))+" confirmed cases. It's State "+parsed_json.get("state").get("state").upper()+" has "+confirmed3+" confirmed, "+active3+" active, "+recovered3+" recovered, "+deaths3+" deaths and a total of "+str(total3)+" cases. You can use phrases like \'active cases in 530043\', \'Bengaluru deaths\', \'Confirmed cases in Tamil Nadu\' or \'map state deaths\' to get specific information. Thank you!"
            finalMessageResp = '{"fulfillmentMessages":[{"text": {"text": ["'+finalMessage+'"]}},{"card":{"title":"",subtitle":"","imageUri":"https://maps.googleapis.com/maps/api/staticmap?center='+parsed_json.get("district")+','+parsed_json.get("state").get("state")+'&zoom=13&size=600x300&maptype=roadmap&markers=color:blue|label:S|40.702147,-74.015794&markers=color:green|label:G|40.711614,-74.012318&markers=color:red|label:C|40.718217,-73.998284&key=REMOVED-KEY-HERE"}}]}'
        elif(stateJSON.find("statesuccess")>-1):
            res11 = stateJSON.strip('"')
            app.logger.error(res11)
            app.logger.error("res11")
            res11 = res11.replace('\\','')
            parsed_json = (json.loads(res11))
            loaded_json = json.loads(json.dumps(parsed_json, indent=4, sort_keys=True))
            active4 = parsed_json.get("active")
            confirmed4 = parsed_json.get("confirmed")
            recovered4 = parsed_json.get("recovered")
            deaths4 = parsed_json.get("deaths")
            total4 = int(active4)+int(confirmed4)+int(recovered4)+int(deaths4)
            finalMessage = parsed_json.get("state").upper()+" has reported "+confirmed4+" confirmed, "+active4+" active, "+recovered4+" recovered, "+deaths4+" deaths and a total "+str(total4)+" cases. You can use phrases like \'active cases in 530043\', \'Bengaluru deaths\', \'Confirmed cases in Tamil Nadu\' or \'map state deaths\' to get specific information. Thank you!"
            finalMessageResp = '{"fulfillmentMessages":[{"text": {"text": ["'+finalMessage+'"]}},{"card":{"title":"",subtitle":"","imageUri":"https://maps.googleapis.com/maps/api/staticmap?center='+parsed_json.get("state")+'&zoom=8&size=800x600&maptype=roadmap&markers=color:blue|label:S|40.702147,-74.015794&markers=color:green|label:G|40.711614,-74.012318&markers=color:red|label:C|40.718217,-73.998284&key=REMOVED-KEY-HERE"}}]}'
        elif(cityJSON.find("citymultiple")>-1 or stateJSON.find("statemultiple")>-1):
            finalMessage='Huh!! Did not find the exact location. However, here are some close matches that you will find helpful. '
            num=0
            if(cityJSON.find("citymultiple")>-1):
                res11 = cityJSON.strip('"')
                res11 = res11.replace('\\','')
                parsed_json11 = (json.loads(res11))
                loaded_json11 = json.loads(json.dumps(parsed_json11, indent=4, sort_keys=True))
                for citiesObj in parsed_json11.get("cities"):
                    num=num+1
                    active1 = citiesObj.get("state").get("active")
                    confirmed1 = citiesObj.get("state").get("confirmed")
                    recovered1 = citiesObj.get("state").get("recovered")
                    deaths1 = citiesObj.get("state").get("deaths")
                    total1 = int(active1)+int(confirmed1)+int(recovered1)+int(deaths1)
                    finalMessage = finalMessage + " ("+str(num)+") "+citiesObj.get("city").upper()+" has "+citiesObj.get("confirmed")+" confirmed cases"
            if(stateJSON.find("statemultiple")>-1):
                res22 = stateJSON.strip('"')
                res22 = res22.replace('\\','')
                parsed_json22 = (json.loads(res22))
                loaded_json22 = json.loads(json.dumps(parsed_json22, indent=4, sort_keys=True))
                for statesObj in parsed_json22.get("states"):
                    num=num+1
                    active2 = statesObj.get("active")
                    confirmed2 = statesObj.get("confirmed")
                    recovered2 = statesObj.get("recovered")
                    deaths2 = statesObj.get("deaths")
                    total2 = int(active2)+int(confirmed2)+int(recovered2)+int(deaths2)
                    finalMessage = finalMessage + " ("+str(num)+") "+statesObj.get("state").upper()+" has recorded "+confirmed2+" confirmed, "+active2+" active, "+recovered2+" recovered, "+deaths2+" deaths, and total "+str(total2)+" cases. "
            finalMessage = finalMessage + "You can use phrases like \'active cases in 530043\', \'Bengaluru deaths\', \'Confirmed cases in Tamil Nadu\' or \'map state deaths\' to get specific information. Thank you!"
            finalMessageResp = '{"fulfillmentMessages":[{"text": {"text": ["'+finalMessage+'"]}}]}'
        else:
            finalMessage = "Ouch!!! I had some trouble to understand that location. You can always use phrases like \'active cases in 530043\', \'Bengaluru deaths\' or \'Confirmed in Tamil Nadu\' to get specific COVID case details based on your pin code, city or state within India. Thank you!"
            finalMessageResp = '{"fulfillmentMessages":[{"text": {"text": ["'+finalMessage+'"]}}]}'
    dynamodb = boto3.resource('dynamodb')
    print("111")
    table = dynamodb.Table('CovidDialogFlowConversation')
    print("222")
    try:
        print("333::"+userId+":::"+str(int(round(time.time() * 1000)))+":::"+userLocation+":::"+caseType+":::"+finalMessage)
        table.put_item(
            Item={
                'SessionID': userId+"|||"+str(int(round(time.time() * 1000))),
                'userLocation': userLocation,
                'caseType': caseType,
                'botresponse':finalMessage
            }
        )    
        print("Conversation Stored for "+userId)
    except Exception as e:
        #print(e.response)
        #print(e.response['Error'])
        #print(e.response['Error']['Message'])
        print("Some exception in inserting conversation::"+str(e))
    
    return finalMessageResp

@app.route('/',methods=['GET','POST'])
def welcome():
    app.logger.error("Welcome")
    now = datetime.datetime.now()
    app.logger.error(now)
    req = request.get_json(silent=True, force=True)
    app.logger.error(req)
    if(req and req.get('session')):
        sessionID = req.get('session').replace("projects/covid-jvqwuu/agent/sessions/","")
        sessionID=sessionID[:sessionID.find("/")]
    else:
        sessionID=str(int(round(time.time() * 1000)))
    app.logger.error("sessionID::"+sessionID)
    queryResult = req.get('queryResult')
    outputContexts = queryResult.get('outputContexts')
    userName='testname'
    userEmail='testemail@email.com'
    userPhone='12121212'
    userLocation='530043'
    #sessionID=''
    if(queryResult.get("intent") and queryResult.get("intent") and queryResult.get("intent").get("displayName") and queryResult.get("intent").get("displayName")=="CasesByLocationByType"):
        caseLocation = queryResult.get("parameters").get("caseLocation")
        caseType = queryResult.get("parameters").get("caseType")
        #sessionID=queryResult.get("name")
        retstr = dialogFlowInput(caseLocation,caseType,sessionID)
        r = make_response(retstr)
        r.headers['Content-Type'] = 'application/json'
        return r
    elif(queryResult.get("intent") and queryResult.get("intent") and queryResult.get("intent").get("displayName") and queryResult.get("intent").get("displayName")=="MapDisplay"):
        caseLocation = queryResult.get("parameters").get("locationType")
        caseType = queryResult.get("parameters").get("caseType")
        if(caseLocation=='city'):
            finalMessageResp = '{"fulfillmentMessages":[{"text": {"text": ["The below link has a map view for the cases across all cities in India. https://ineuron-chatbot.s3.amazonaws.com/city-all.html"]}}]}'
        elif(caseLocation=='state'):
            #state
            if(caseType=="active"):
                #active
                #https://ineuron-chatbot.s3.amazonaws.com/state-active.html
                finalMessageResp = '{"fulfillmentMessages":[{"text": {"text": ["State Level Active COVID Cases across India can be found in below link. https://ineuron-chatbot.s3.amazonaws.com/state-active.html"]}}]}'
            elif(caseType=="deaths"):
                #deaths
                #https://ineuron-chatbot.s3.amazonaws.com/state-deaths.html
                finalMessageResp = '{"fulfillmentMessages":[{"text": {"text": ["Death numbers per each State in India is available in below link https://ineuron-chatbot.s3.amazonaws.com/state-deaths.html"]}}]}'
            elif(caseType=="confirmed"):
                #confirmed
                #https://ineuron-chatbot.s3.amazonaws.com/state-confirmed.html
                finalMessageResp = '{"fulfillmentMessages":[{"text": {"text": ["https://ineuron-chatbot.s3.amazonaws.com/state-confirmed.html link has the state wise confirmed cases across India"]}}]}'
            elif(caseType=="recovered"):
                #recovered
                #https://ineuron-chatbot.s3.amazonaws.com/state-recovered.html
                finalMessageResp = '{"fulfillmentMessages":[{"text": {"text": ["Recovered cases across various states in India can be found in below link https://ineuron-chatbot.s3.amazonaws.com/state-recovered.html"]}}]}'
            else:
                #all
                #https://ineuron-chatbot.s3.amazonaws.com/state-all.html
                finalMessageResp = '{"fulfillmentMessages":[{"text": {"text": ["Hmmm, i believe you meant to see all cases across various states in India. Below link can be of great help!! https://ineuron-chatbot.s3.amazonaws.com/state-all.html"]}}]}'
        else:
            #country/world
            if(caseType=="active"):
                #active
                #https://ineuron-chatbot.s3.amazonaws.com/country-active.html
                finalMessageResp = '{"fulfillmentMessages":[{"text": {"text": ["Country Level Active COVID Cases across the Globe can be found in below link. https://ineuron-chatbot.s3.amazonaws.com/country-active.html"]}}]}'
            elif(caseType=="deaths"):
                #deaths
                #https://ineuron-chatbot.s3.amazonaws.com/country-deaths.html
                finalMessageResp = '{"fulfillmentMessages":[{"text": {"text": ["Death numbers in each country around the world are available in below link https://ineuron-chatbot.s3.amazonaws.com/country-deaths.html"]}}]}'
            elif(caseType=="recovered"):
                #recovered
                #https://ineuron-chatbot.s3.amazonaws.com/country-recovered.html
                finalMessageResp = '{"fulfillmentMessages":[{"text": {"text": ["Recovered cases across various countries can be found in below link https://ineuron-chatbot.s3.amazonaws.com/country-recovered.html"]}}]}'
            else:
                #all
                #https://ineuron-chatbot.s3.amazonaws.com/country-all.html
                finalMessageResp = '{"fulfillmentMessages":[{"text": {"text": ["Didnt quite get that. I trust you meant to see all cases across various countries. Below url has exactly that information https://ineuron-chatbot.s3.amazonaws.com/country-all.html"]}}]}'
        finalMessageResp = finalMessageResp + ". Note that the links fetch  Also the link above fetches data real time, and hence might take time to open"
        r = make_response(finalMessageResp)
        r.headers['Content-Type'] = 'application/json'
        return r
    else:
        #sessionID=''
        for parameters in outputContexts:
            if(parameters.get("parameters").get("userName")):
                userName = parameters.get("parameters").get("userName")
            elif(parameters.get("parameters").get("userEmail")):
                userEmail = parameters.get("parameters").get("userEmail")
            elif(parameters.get("parameters").get("userPhone")):
                userPhone = parameters.get("parameters").get("userPhone")
            elif(parameters.get("parameters").get("userLocation")):
                userLocation = parameters.get("parameters").get("userLocation")
            #sessionID=parameters.get("name").replace("projects/covid-jvqwuu/agent/sessions/","")
            #sessionID=sessionID[:sessionID.find("/")]
            
        app.logger.error("userName::"+userName+" and userEmail::"+userEmail)
        app.logger.error("userPhone::"+userPhone+" and userLocation::"+userLocation)
        app.logger.error("sessionID:::"+sessionID)
        now = datetime.datetime.now()
        app.logger.error("Before Sending Email--"+str(now))
        #sendCovidEmail(userEmail,userName)
        now = datetime.datetime.now()
        app.logger.error("After Sending Email--"+str(now))
        app.logger.error("Before Data Insert--"+str(now))
        insertUserData(sessionID,userName,userPhone,userEmail)
        now = datetime.datetime.now()
        app.logger.error("AFter Data Insert--"+str(now))
        app.logger.error("Before Actual Processing--"+str(now))
        retstr = dialogFlowInput(userLocation,'total',sessionID)
        now = datetime.datetime.now()
        app.logger.error("AFter Actual Processing--"+str(now))
        r = make_response(retstr)
        r.headers['Content-Type'] = 'application/json'
        return r

def sendCovidEmail(userEmail,userName):
    print("in sendEmail")
    now = datetime.datetime.now()
    app.logger.error(now)
    msg = MIMEMultipart()
    msg['From'] = "sunkarimahidhar85@gmail.com"
    msg['To'] = userEmail
    #print("student email::" + recepient_email);
    msg['Subject'] = "India Covid Report & Precautions"
    htmldata = '<html><head><title>India COVID Detail Report</title></head><body style="background:lightgrey">Hello <strong>XXXXX</strong>,<br/><br/><br/>Hope all is well with you. This email contains the current reported COVID-19 cases in India in various states. Also given below are some precautions to follow. Please stay safe!!<div id="intro">Protect yourself and others around you by knowing the facts and taking appropriate precautions. Follow advice provided by your local public health agency.<br/><br/>To prevent the spread of COVID-19:<ul><li>Clean your hands often. Use soap and water, or an alcohol-based hand rub.</li><li>Maintain a safe distance from anyone who is coughing or sneezing.</li><li>Donot touch your eyes, nose or mouth.</li><li>Cover your nose and mouth with your bent elbow or a tissue when you cough or sneeze.</li><li>Stay home if you feel unwell.</li><li>If you have a fever, a cough, and difficulty breathing, seek medical attention. Call in advance.</li><li>Follow the directions of your local health authority.</li></ul><br/>Avoiding unneeded visits to medical facilities allows healthcare systems to operate more effectively, therefore protecting you and others.<br/><br/>Thanks,<br/>Google Dialog Flow Bot</body></html>'
    htmldata = htmldata.replace("XXXXX",userName)
    totalStr=''
    #request = requests.get("https://api.covid19india.org/data.json")
    #pageData = json.loads(request.text)
    #statesjson = pageData.get("statewise")
    #num=0
    #now = datetime.datetime.now()
    #app.logger.error(now)
    #for stateObj in statesjson:
    #    num=num+1
    #    if(num<=1):
    #        continue
    #    confirmed = int(stateObj.get('confirmed'))
    #    deaths =  int(stateObj.get('deaths'))
    #    active  = int(stateObj.get('active'))
    #    recovered  = int(stateObj.get('recovered'))
    #    total = confirmed+deaths+active+recovered
    #    recordStr=""
    #    recordStr="<tr><td>"+stateObj.get('state')+"</td>"
    #    recordStr=recordStr+"<td>"+stateObj.get('active')+"</td><td>"+stateObj.get('recovered')+"</td>"
    #    recordStr=recordStr+"<td>"+stateObj.get('confirmed')+"</td><td>"+stateObj.get('deaths')+"</td>"
    #    recordStr=recordStr+"<td>"+str(total)+"</td></tr>"
    #    totalStr = totalStr+recordStr
    now = datetime.datetime.now()
    app.logger.error(now)
    htmldata = htmldata.replace("YYYYYYYYYYYYYYYYYYYY",totalStr)
    msg.attach(MIMEText(htmldata, 'html'))
    #request11 = requests.get("https://ineuron-chatbot.s3.amazonaws.com/covid-precautions.pdf")
    #attachment_data = request11.content
    #payload = MIMEBase('application', 'octet-stream')
    #payload.set_payload(attachment_data)
    #encoders.encode_base64(payload) #encode the attachment
    #add payload header with filename
    #payload.add_header('Content-Disposition', 'attachment', filename='covid-precautions.pdf')
    #payload.add_header('Content-Type', 'application/pdf')
    #msg.attach(payload)
    now = datetime.datetime.now()
    app.logger.error(now)
    smtp = smtplib.SMTP('mail.smtp2go.com', 2525)
    smtp.starttls()
    smtp.login("cognizant.com","cognizant@123")
    text = msg.as_string()
    smtp.sendmail("sunkarimahidhar85@gmail.com", userEmail, text)
    smtp.quit()
    now = datetime.datetime.now()
    app.logger.error(now)

if __name__ == '__main__':
    app.run(debug = True)